<html>
<head>
	<link rel="alternate stylesheet" type="text/css" title="Ter_Dark_Blue" href="./css/Ter_Dark_Blue.css">
    <link rel="alternate stylesheet" type="text/css" title="Ter_Light" href="./css/Ter_Light.css">
    <link rel="alternate stylesheet" type="text/css" title="TypeW_Dark" href="./css/TypeW_Dark.css">
    <link rel="alternate stylesheet" type="text/css" title="TypeW_Light" href="./css/TypeW_Light.css">

<meta http-equiv="Default-Style" content="Ter_Dark_Blue"> 
</head>	

<body onload="set_style_from_cookie()">
<script type="text/javascript" src="../js/JS_Alterar_Tema.js"></script>

<?php
class C_Nome 
{
public $Pri_Nome_Str1 = "Primeiro Nome 1";
public $Pri_Nome_Str2 = "Primeiro Nome 2";
public $Seg_Nome_Str1 = "Segundo Nome 1";
public $Seg_Nome_Str2 = "Segundo Nome 2";
public $Apelido = "Apelido";
public string $Nome_C;
public string $Nome_L;



public function ReqNomeCurto($Nome_C) { 
$this -> $Pri_Nome_Str1;
$this -> $Apelido;
$this -> $Seg_Nome_Str1;
$this -> $Nome_C = ("$Pri_Nome_Str1 "+" $Apelido "+" $Seg_Nome_Str1");
echo "<h2>$Nome_C</h2>";
}

public function ReqNomeLongo($Nome_L) { 
$this -> $Pri_Nome_Str1;
$this -> $Pri_Nome_Str2;
$this -> $Apelido;
$this -> $Seg_Nome_Str1;
$this -> $Seg_Nome_Str2;
$this -> $Nome_L = ("$Pri_Nome_Str1 "+"$Pri_Nome_Str2"+"$Apelido "+"$Seg_Nome_Str1 "+" $Seg_Nome_Str2");
echo "<h2>$Nome_L</h2>";
}




}

$Nome_Albrecht_L = new C_Nome();
$Nome_Albercht_C = new C_Nome();

$Nome_Albrecht_C -> $Pri_Nome_Str1= "Albrecht";
$Nome_Albrecht_C -> $Apelido = "Commandant";
$Nome_Albrecht_C -> $Seg_Nome_Str1= "Adler";
$Nome_Albrecht_C -> ReqNomeCurto();


$Nome_Albrecht_L -> $Pri_Nome_Str1= "Albrecht";
$Nome_Albrecht_L -> $Pri_Nome_Str2= "Reinhard";
$Nome_Albrecht_L -> $Apelido = "Commandant";
$Nome_Albrecht_L -> $Seg_Nome_Str1= "Adler";
$Nome_Albrecht_L -> $Seg_Nome_Str2= "Eugen";
$Nome_Albrecht_L->ReqNomeLongo( );




$Nome_Redmond_L = new C_Nome();
$Nome_Redmond_C = new C_Nome();



$Nome_Redmond_L -> $Pri_Nome_Str1= "João";
$Nome_Redmond_L -> $Pri_Nome_Str2= "Alberto";
$Nome_Redmond_L -> $Apelido = "Crimson Red";
$Nome_Redmond_L -> $Seg_Nome_Str1= "Moreira";
$Nome_Redmond_L -> $Seg_Nome_Str2= "Agusto";
$Nome_Redmond_L->ReqNomeLongo( );


$Nome_Redmond_C -> $Pri_Nome_Str1= "João";
$Nome_Redmond_C -> $Apelido = "Crimson Red";
$Nome_Redmond_C-> $Seg_Nome_Str1= "Moreira";
$Nome_Redmond_C ->ReqNomeCurto();


$Nome_Tulio_L = new C_Nome();
$Nome_Tulio_L = new C_Nome();

$Nome_Tulio_L -> $Pri_Nome_Str1= "Tulio";
$Nome_Tulio_L -> $Pri_Nome_Str2= "Rafael";
$Nome_Tulio_L -> $Apelido = "Tecno-Harmonista";
$Nome_Tulio_L -> $Seg_Nome_Str1= "Barbosa";
$Nome_Tulio_L -> $Seg_Nome_Str2= "Joaquim";
$Nome_Tulio_L ->ReqNomeLongo();

$Nome_Tulio_C -> $Pri_Nome_Str1= "Tulio";
$Nome_Tulio_C -> $Apelido = "Tecno-Harmonista";
$Nome_Tulio_C -> $Seg_Nome_Str1= "Barbosa";
$Nome_Tulio_C->ReqNomeCurto();

$Nome_Eduard_L = new C_Nome();
$Nome_Eduard_C = new C_Nome();



$Nome_Eduard_L -> $Pri_Nome_Str1="Eduard";
$Nome_Eduard_L -> $Pri_Nome_Str2= "Grigori";
$Nome_Eduard_L -> $Apelido = "Limonka";
$Nome_Eduard_L -> $Seg_Nome_Str1= "Aquila";
$Nome_Eduard_L -> $Seg_Nome_Str2= "Gustav";
$Nome_Eduard_L ->ReqNomeLongo();

$Nome_Eduard_C -> $Pri_Nome_Str1="Eduard";
$Nome_Eduard_C -> $Apelido = "Limonka";
$Nome_Eduard_C -> $Seg_Nome_Str1= "Aquila";
$Nome_Eduard_C->ReqNomeCurto();


?>
<a href="../phps_index.html"><h2>Retornar a Lista De Atividades</h2></a>

</html>
