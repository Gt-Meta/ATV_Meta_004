<html>
<head>
	<link rel="alternate stylesheet" type="text/css" title="Ter_Dark_Blue" href="../css/Ter_Dark_Blue.css">
    <link rel="alternate stylesheet" type="text/css" title="Ter_Light" href="../css/Ter_Light.css">
    <link rel="alternate stylesheet" type="text/css" title="TypeW_Dark" href="../css/TypeW_Dark.css">
    <link rel="alternate stylesheet" type="text/css" title="TypeW_Light" href="../css/TypeW_Light.css">

<meta http-equiv="Default-Style" content="Ter_Dark_Blue"> 
</head>	

<body onload="set_style_from_cookie()">
<script type="text/javascript" src="../js/JS_Alterar_Tema.js"></script>
</head>	

<body onload="set_style_from_cookie()">
<script type="text/javascript" src="http://localhost/meta_2021/Projetos/Alteração_Tema/JS_Alterar_Tema.js"></script>

<?php
class C_Prod
{
public $Tipos_Prod = "Tipo De Produto ";	
public $Tipo_Prod_1 = "Tipo De Produto 1";
public $Tipo_Prod_2 = "Tipo De Produto 2";
public $Tipo_Prod_3 = "Tipo De Produto 3";
public $Tipo_Prod_4 = "Tipo De Produto 4";
public $Tipo_Prod_5 = "Tipo De Produto 5";

public float $Preço_Prod;
public float $Preço_Prod_1;
public float $Preço_Prod_2;
public float $Preço_Prod_3;
public float $Preço_Prod_4;
public float $Preço_Prod_5;



public function ReqProdutos() { 
$this -> $Tipo_Prod_1;
$this -> $Tipo_Prod_2;
$this -> $Tipo_Prod_3;
$this -> $Tipo_Prod_4;
$this -> $Tipo_Prod_5;
}

public function ReqPreços() { 
// Preço Por Kg Para Alimentos 
// Preço Por Ml Para Perfumes
// Preço Por Litro Pra Bebidas

$this -> $Preço_Prod_1;
$this -> $Preço_Prod_2;
$this -> $Preço_Prod_3;
$this -> $Preço_Prod_4;
$this -> $Preço_Prod_5;
}




}

$Albercht_Produtos = new C_Prod();

$Albercht_Produtos -> $Tipo_Prod_1 = "Batatas" ;
$Albercht_Produtos -> $Tipo_Prod_2 =  "Carne Suina" ;
$Albercht_Produtos -> $Tipo_Prod_3 = "Carne Bovina" ;
$Albercht_Produtos -> $Tipo_Prod_4 = "Carne de Galhinha" ;
$Albercht_Produtos -> $Tipo_Prod_5 = "Ovos De Galhinha" ;

$Albercht_Preços = new C_Prod();

$Albercht_Preços -> $Preço_Prod_1 = 7.50;
$Albercht_Preços -> $Preço_Prod_2 = 5.55;
$Albercht_Preços -> $Preço_Prod_3 = 8.55;
$Albercht_Preços -> $Preço_Prod_4 =  4.55;
$Albercht_Preços -> $Preço_Prod_5 = 2.50;


$Albercht_Produtos->ReqProdutos();
$Albrecht_Preços->ReqPreços();



$Redmond_Produtos = new C_Prod();

$Redmond_Produtos -> $Tipo_Prod_1 = "Açai" ;
$Redmond_Produtos -> $Tipo_Prod_2 =  "Mandioca" ;
$Redmond_Produtos -> $Tipo_Prod_3 = "Tomate" ;
$Redmond_Produtos -> $Tipo_Prod_4 = "Perfume De Rosas" ;
$Redmond_Produtos -> $Tipo_Prod_5 = "Manjericão" ;

$Redmond_Preços = new C_Prod();

$Redmond_Preços -> $Preço_Prod_1 = 3.25;
$Redmond_Preços -> $Preço_Prod_2 = 6.65;
$Redmond_Preços -> $Preço_Prod_3 = 3.90;
$Redmond_Preços -> $Preço_Prod_4 =  10.50;
$Redmond_Preços -> $Preço_Prod_5 = 2.50;

$Redmond_Produtos ->ReqProdutos();
$Redmond_Preços ->ReqPreços();


$Tulio_Produtos = new C_Prod();
$Tulio_Produtos -> $Tipo_Prod_1 = "Algodão" ;
$Tulio_Produtos -> $Tipo_Prod_2 =  "Açucar" ;
$Tulio_Produtos -> $Tipo_Prod_3 = "Caldo De Cana" ;
$Tulio_Produtos -> $Tipo_Prod_4 = "Maçã" ;
$Tulio_Produtos -> $Tipo_Prod_5 = "Suco De Macã" ;



$Tulio_Preços = new C_Prod();
$Tulio_Preços -> $Preço_Prod_1 = 2.45;
$Tulio_Preços -> $Preço_Prod_2 = 4.25;
$Tulio_Preços -> $Preço_Prod_3 = 6.25;
$Tulio_Preços -> $Preço_Prod_4 =  2.65;
$Tulio_Preços -> $Preço_Prod_5 = 1.50;


$Tulio_Produtos ->ReqProdutos();
$Tulio_Preços->ReqPreços();

$Eduard_Produtos = new C_Prod();
$Eduard_Produtos -> $Tipo_Prod_1 = "Batatas" ;
$Eduard_Produtos -> $Tipo_Prod_2 =  "Limão" ;
$Eduard_Produtos -> $Tipo_Prod_3 = "Uvas" ;
$Eduard_Produtos -> $Tipo_Prod_4 = "Vodka" ;
$Eduard_Produtos -> $Tipo_Prod_5 = "Vinho" ;

$Eduard_Preços = new C_Prod();
$Eduard_Preços -> $Preço_Prod_1 = 3.45;
$Eduard_Preços -> $Preço_Prod_2 = 4.25;
$Eduard_Preços -> $Preço_Prod_3 = 2.25;
$Eduard_Preços -> $Preço_Prod_4 =  15.50;
$Eduard_Preços -> $Preço_Prod_5 = 35.45;

$Eduard_Produtos ->ReqProdutos();
$Eduard_Preços->ReqPreços();


?>
<a href="../phps_index.html"><h2>Retornar a Lista De Atividades</h2></a>

</html>
