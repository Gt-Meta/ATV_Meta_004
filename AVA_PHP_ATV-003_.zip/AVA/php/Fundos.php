<html>
<head>
	<link rel="alternate stylesheet" type="text/css" title="Ter_Dark_Blue" href="../css/Ter_Dark_Blue.css">
    <link rel="alternate stylesheet" type="text/css" title="Ter_Light" href="../css/Ter_Light.css">
    <link rel="alternate stylesheet" type="text/css" title="TypeW_Dark" href="../css/TypeW_Dark.css">
    <link rel="alternate stylesheet" type="text/css" title="TypeW_Light" href="../css/TypeW_Light.css">

<meta http-equiv="Default-Style" content="Ter_Dark_Blue"> 
</head>	

<body onload="set_style_from_cookie()">
<script type="text/javascript" src="../js/JS_Alterar_Tema.js"></script>

<?php
class C_Fundos
{
public float $Saldos_Vendas;
public float $Impostos;
public float $Custos_Produção;
public float $Outros_Custos;
public float $Outros_Saldos;
public float $Total_Saldos;
public float $Total_Custos;

public function ReqCustos($Total_Custos) { 
$this -> $Custos_Produção;
$this -> $Impostos;
$this -> $Outros_Custos;
$this -> Total_Custos = $Custos_Produção+$Outros_Custos+$Impostos;
return Total_Custos;
}

public function ReqSaldos($Total_Saldos) { 
$this -> $Saldos_Vendas;
$this -> $Outros_Saldos;
$this -> Total_Saldos = $Saldos_Vendas+$Outros_Saldos;
return Total_Saldos;
}




}

$Albercht_Saldos = new C_Fundos();
$Albercht_Saldos  -> $Saldos_Vendas = 20500;
$Albercht_Saldos  -> $Outros_Saldos = 2400;


$Albercht_Custos = new C_Fundos();
$Albercht_Custos  -> $Custos_Produção = 20500;
$Albercht_Custos  -> $Impostos = 2400;
$Albercht_Custos  -> $Outros_Custos = 2400;

$Albercht_Saldos->ReqCustos();
$Albercht_Custos->ReqSaldos();



$Redmond_Saldos = new C_Fundos();
$Redmond_Saldos  -> $Saldos_Vendas = 21500;
$Redmond_Saldos  -> $Outros_Saldos = 6500;

$Redmond_Custos = new C_Fundos();
$Redmond_Custos  -> $Custos_Produção = 4500;
$Redmond_Custos  -> $Impostos = 87755;
$Redmond_Custos  -> $Outros_Custos = 1266;

$Redmond_Custos ->ReqCustos();
$Redmond_Saldos ->ReqSaldos();


$Tulio_Custos = new C_Fundos();
$Tulio_Custos  -> $Custos_Produção = 5000;
$Tulio_Custos  -> $Impostos = 100000;
$Tulio_Custos  -> $Outros_Custos = 1405;



$Tulio_Saldos = new C_Fundos();
$Tulio_Saldos  -> $Saldos_Vendas = 20000;
$Tulio_Saldos  -> $Outros_Saldos = 1350;


$Tulio_Custos ->ReqCustos();
$Tulio_Saldos->ReqSaldos();

$Eduard_Saldos = new C_Fundos();
$Eduard_Saldos  -> $Saldos_Vendas = 25000;
$Eduard_Saldos  -> $Outros_Saldos = 1250;


$Eduard_Custos = new C_Fundos();
$Eduard_Custos  -> $Custos_Produção = 5000;
$Eduard_Custos  -> $Impostos = 100000;
$Eduard_Custos  -> $Outros_Custos = 1605;


$Eduard_Custos ->ReqCustos();
$Eduard_Saldos->ReqSaldos();


?>
<a href="../phps_index.html"><h2>Retornar a Lista De Atividades</h2></a>

</html>
