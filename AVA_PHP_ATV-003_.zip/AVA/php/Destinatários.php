<html>
<head>
	<link rel="alternate stylesheet" type="text/css" title="Ter_Dark_Blue" href="../css/Ter_Dark_Blue.css">
    <link rel="alternate stylesheet" type="text/css" title="Ter_Light" href="../css/Ter_Light.css">
    <link rel="alternate stylesheet" type="text/css" title="TypeW_Dark" href="../css/TypeW_Dark.css">
    <link rel="alternate stylesheet" type="text/css" title="TypeW_Light" href="../css/TypeW_Light.css">

<meta http-equiv="Default-Style" content="Ter_Dark_Blue"> 
</head>	

<body onload="set_style_from_cookie()">
<script type="text/javascript" src="../js/JS_Alterar_Tema.js"></script>

<?php
class C_Entregas
{
public $Nome_Org_Dest = "Nome Da Organização Do Destinatário";
public $Nome_Loc_Dest = "Localização Do Destinatário";
public $Produtos_Entregues = "Produtos Entregues";
public $TE_Inicial = "Tempo Estimado  Inicial Da Entrega";
public $TEC = "Tempo Estimado De Chegada";
public array $Tempo_Entrega;
public float $Pagamento_Estimado;



public function ReqDadosEntrega() { 
$this ->  $Nome_Org_Dest;
$this ->  $Nome_Loc_Dest;
$this ->  $Produtos_Entregues;
echo  "<h2>$Produtos_Entregues</h2>";
echo  "<h2>$Nome_Org_Dest</h2>";
echo  "<h2>$Nome_Loc_Dest</h2>";
}


public function ReqTempoEstimado() { 
$this ->  $TE_Inicial;
$this ->  $TEC;
$this ->  $Tempo_Entrega = ("$TE_Inicial"+" / "+$TEC);
echo "<h2>$Tempo_Entrega</h2>";
}

public function ReqPagamento() { 
$this ->  $Pagamento_Estimado;
echo "<h2>$Pagamento_Estimado</h2>";
}


}

$E_Albercht_01_Dados = new C_Entrega();

$E_Albercht_01_Dados -> $Nome_Org_Dest= "Supermercados Agusto";
$E_Albercht_01_Dados -> $Nome_Loc_Dest = "94510-292 - Travessa Sperotto, 677 - Viamão, RS";
$E_Albercht_01_Dados -> $Produtos_Entregues="950KG De Batatas,  750KG De Carne Bovina E 855KG De Carne De Galhina" ; 

$E_Albercht_01_Tempo = new C_Entrega();


$E_Albercht_01_Pag = new C_Entrega();


$E_Redmond_01_Dados = new C_Entrega();


$E_Redmond_01_Tempo = new C_Entrega();


$E_Redmond_01_Pag = new C_Entrega();


$E_Tulio_01_Dados = new C_Entrega();


$E_Tulio_01_Tempo = new C_Entrega();


$E_Tulio_01_Pag = new C_Entrega();


$E_Eduard_01_Dados = new C_Entrega();


$E_Eduard_01_Tempo = new C_Entrega();


$E_Eduard_01_Pag = new C_Entrega();


?>
<a href="../phps_index.html"><h2>Retornar a Lista De Atividades</h2></a>

</html>
