<html>
<head>
	<link rel="alternate stylesheet" type="text/css" title="Ter_Dark_Blue" href="../css/Ter_Dark_Blue.css">
    <link rel="alternate stylesheet" type="text/css" title="Ter_Light" href="../css/Ter_Light.css">
    <link rel="alternate stylesheet" type="text/css" title="TypeW_Dark" href="../css/TypeW_Dark.css">
    <link rel="alternate stylesheet" type="text/css" title="TypeW_Light" href="../css/TypeW_Light.css">
     <meta http-equiv="Default-Style" content="Ter_Dark_Blue"> 

</head>	

<body onload="set_style_from_cookie()">
<script type="text/javascript" src="../js/JS_Alterar_Tema.js"></script>

<?php
class C_Org {
public $Nome_Org = "Nome Da Organização";
public $Func_Org = "Função Da Organização";
public $Endereço_Princ = "Endereço Principal";
public $Email = "Email";
public $NumTel;
public $Porte = "Porte";
public $Nat_Juri = "Natureza Juridica";
public $CNPJ;



public function ReqOrgInfoCurto() { 
$this -> $Nome_Org;
$this -> $Func_Org;
$this -> $Email;
$this -> $NumTel;
echo "<h2>$Nome_Org</h2>";
echo "<h2>$Func_Org</h2>";
echo "<h2>$NumTel</h2>";
echo "<h2>$Email</h2>";
}

public function ReqOrgInfoLongo() { 
$this -> $Nome_Org;
$this -> $Func_Org;
$this -> $Porte;
$this -> $CNPJ;
$this -> $Email;
$this -> $NumTel;
$this -> $Endereço_Princ;
$this -> $Nat_Juri;
echo "<h2>$Nome_Org</h2>";
echo "<h2>$Func_Org</h2>";
echo "<h2>$Porte</h2>";
echo "<h2>$CNPJ</h2>";
echo "<h2>$Email</h2>";
echo "<h2>$NumTel</h2>";
echo "<h2>$Endereço_Princ</h2>";
echo "<h2>$Nat_Juri</h2>";
}




}

$Org_Albercht_L = new C_Org();

$Org_Albercht_L  -> $Nome_Org = "Adler Alimentos";
$Org_Albercht_L  -> $Func_Org = "Produção de alimentos";
$Org_Albercht_L  -> $Porte = "Médio";
$Org_Albercht_L  -> $CNPJ = "31.707.623/0001-22";
$Org_Albercht_L  -> $Email = "AlimentosAdler@gmail.com";
$Org_Albercht_L  -> $NumTel = mt_rand(55941111111, 55954999999);
$Org_Albercht_L  -> $Endereço_Princ = "Rua Doutor Mário da Costa Pereira 94960-190 - RS, Cachoeirinha";
$Org_Albercht_L  -> $Nat_Juri = "SLU";
$Org_Albrecht_L->ReqOrgInfoLongo();




$Org_Albercht_C = new C_Nome();

$Org_Albercht_C -> $Nome_Org = "Adler Alimentos";
$Org_Albercht_C  -> $Func_Org = "Produção de alimentos";
$Org_Albercht_C  -> $NumTel = mt_rand(55411111111, 55999999999);
$Org_Albercht_C  -> $Email = "AlimentosAdler@gmail.com";

$Org_Albrecht_C->ReqOrgInfoCurto();



$Org_Redmond_L = new C_Org();

$Org_Redmond_L  -> $Nome_Org = "Produtos Naturais Rena&Redmond";
$Org_Redmond_L  -> $Func_Org = "Produção de alimentos e produtos naturais";
$Org_Redmond_L  -> $Porte = "Médio";
$Org_Redmond_L  -> $CNPJ = "04.069.336/0001-61";
$Org_Redmond_L  -> $Email = ;"R&R_Produtos@gmail.com";
$Org_Redmond_L  -> $NumTel = mt_rand(55931111111, 55997999999);
$Org_Redmond_L  -> $Endereço_Princ = "Rua Aristides da Rocha 94960-190 - AM, Manaus";
$Org_Redmond_L  -> $Nat_Juri = "SLU";

$Org_Redmond_L->ReqOrgInfoLongo();


$Org_Redmond_C = new C_Nome();

$Org_Redmond_C -> $Nome_Org = "Produtos Naturais Rena&Redmond";
$Org_Redmond_C  -> $Func_Org = "Produção de alimentos e produtos naturais";
$Org_Redmond_C  -> $NumTel = mt_rand(559921111111, 55994999999);
$Org_Redmond_C  -> $Email = "R&R_Produtos@gmail.com";

$Org_Redmond_C->ReqOrgInfoCurto();

$Org_Tulio_L = new C_Org();

$Org_Tulio_L  -> $Nome_Org = "Cooperativa Maria-Rafael";
$Org_Tulio_L  -> $Func_Org = "Cooperativa Agricola";
$Org_Tulio_L  -> $Porte = "Pequeno";
$Org_Tulio_L  -> $CNPJ = "70.867.770/0001-11";
$Org_Tulio_L  -> $Email = "M&R_Cooperativa@mailfence.com";
$Org_Tulio_L  -> $NumTel = "551227614057";
$Org_Tulio_L  -> $Endereço_Princ = "Rua José Gomez Diaz 12405-230 - SP, Pindamonhangaba";
$Org_Tulio_L  -> $Nat_Juri = "Sociedade Simples Limitada";

$Org_Tulio_L->ReqOrgInfoLongo();


$Org_Tulio_C = new C_Nome();

$Org_Tulio_C  ->  $Nome_Org = "Cooperativa Maria-Rafael";
$Org_Tulio_C  ->  $Func_Org = "Cooperativa Agricola";
$Org_Tulio_C  ->  $NumTel = "551227614057";
$Org_Tulio_C  ->  $Email = "M&R_Cooperativa@mailfence.com";

$Org_Tulio_C->ReqOrgInfoCurto();

$Org_Eduard_L = new C_Org();

$Org_Eduard_L  -> $Nome_Org = "Associação Agricola Aquila";
$Org_Eduard_L  -> $Func_Org = "Cooperativa Agricola" ;
$Org_Eduard_L  -> $Porte = "Médio";
$Org_Eduard_L  -> $CNPJ = "70.867.770/0001-11";
$Org_Eduard_L  -> $Email = "A_Agri_Aquila@tutanota.com";
$Org_Eduard_L  -> $NumTel = "553839131410";
$Org_Eduard_L  -> $Endereço_Princ = "Rua Sagrada Família de Nazaré 39404-846 - MG, Montes Claros";
$Org_Eduard_L  -> $Nat_Juri = "Sociedade Simples Limitada";

$Org_Eduard_L->ReqOrgInfoLongo();

$Org_Eduard_L  ->  $Nome_Org = "Associação Agricola Aquila";
$Org_Eduard_L  ->  $Func_Org = "Cooperativa Agricola" ;
$Org_Eduard_L  ->  $NumTel = "553839131410";
$Org_Eduard_L  ->  $Email = "A_Agri_Aquila@tutanota.com";


$Org_Eduard_C = new C_Nome();
$Org_Eduard_C->ReqOrgInfoCurto();


?>
<a href="../phps_index.html"><h2>Retornar a Lista De Atividades</h2></a>

</html>
